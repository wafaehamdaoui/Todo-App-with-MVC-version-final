#ifndef RETRY_H
#define RETRY_H
#include <QMainWindow>

class Retry:public QMainWindow
{
public:
    Retry(QWidget *parent = nullptr);
};

#endif // RETRY_H
