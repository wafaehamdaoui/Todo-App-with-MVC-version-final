#include "retry.h"
#include "mainwindow.h"
#include <QApplication>
#include <QMessageBox>

Retry::Retry(QWidget *parent)
             : QMainWindow(parent)
{
    auto reply = QMessageBox::question(this , "Exit",
                                       " Username or password is not correct , Do you  want to retry?");
    if(reply == QMessageBox::Yes){
   MainWindow w;
   w.show();
   }else{

        qApp->exit();}
}
