#ifndef LOGIN_H
#define LOGIN_H
#include <QSqlDatabase>
#include <QDialog>


namespace Ui {
class Login;
}

class Login : public QDialog
{
    Q_OBJECT

public:
    explicit Login(QWidget *parent = nullptr);
    ~Login();
public:
    bool acceptLogin=false;

protected:
    void connectDataBase();
    void Addquery(QString username ,QString password);

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_login_clicked();

private:
    Ui::Login *ui;
    QSqlDatabase db;


};

#endif // LOGIN_H
