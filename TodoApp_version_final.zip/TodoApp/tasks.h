#ifndef TASKS_H
#define TASKS_H

#include <QDialog>

namespace Ui {
class Tasks;
}

class Tasks : public QDialog
{
    Q_OBJECT

public:
    explicit Tasks(QWidget *parent = nullptr);
    ~Tasks();
    bool isCompleted() const;
    bool isToday();

    QString getDescription() const;
    QString getTag() const;
    QString getDate() const;


    void setDescription(QString description) const;
    void setTag(QString tag) const;
    void SetDate(QDate date) const;
    void setFinished();


public:
    Ui::Tasks *ui;
};

#endif // TASKS_H
