#include "login.h"
#include "createcount.h"
#include "ui_login.h"
#include "mainwindow.h"
#include <QMessageBox>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QDebug>

Login::Login(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Login)
{
    ui->setupUi(this);
    connectDataBase();
    Addquery("M.belcaid","000000");
    Addquery("wafae","123456");


//         QMessageBox::critical(this,"Error","could not insert the user");
}

Login::~Login()
{
    delete ui;
}

void Login::on_login_clicked()
{
    QString Username = ui->username->text();
        QString Password = ui->password->text();

        if(!db.isOpen()){

            qDebug()<<"Failed to open the database!!";
            return;
        }

    QSqlQuery query;
    if(query.exec("select * from Login where username='"+Username+"' and password='"+Password+"'")){
        int count=0;
        while (query.next()) {
            count++;
        }
        if(count==1){
//            ui->label_3->setText("username and password is correct");
            QMessageBox::information(this,"Access","welcome "+Username);

            acceptLogin = true;
        }

        if(count<1){
//            ui->label_3->setText("username and password is not correct");
            QMessageBox::critical(this,"Error","username or password in not correct !! ");
            acceptLogin = false;
        }
    }
}

void Login::on_pushButton_2_clicked()
{
    //Creating the dialog
     CreateCount D;

   //Executing the dialog and storing the user response
    auto reply = D.exec();

   //Checking if the dialog is accepted
    if(reply == CreateCount::Accepted)
     {
    auto query = new QSqlQuery(db);
    QString insert{"INSERT INTO Login Values('%1','%2')"};
    if(!query->exec(insert.arg(D.getusername()).arg(D.getpassword())))
         QMessageBox::critical(this,"Error","could not insert the user");
    else
        D.close();
    }
}

void Login::connectDataBase(){

    //create database
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("C:\\Users\\Hello\\Desktop\\db\\Logindb.db");
    if(!db.open())
        QMessageBox::critical(this,"Error","could not open the database");

    //create table
    auto query = new QSqlQuery(db);
    QString create{"CREATE TABLE IF NOT EXISTS Login (username varchar(30), password varchar(30))"};
    if(!query->exec(create))
        QMessageBox::critical(this,"Error","could not open the table");



}
void Login::Addquery(QString username ,QString password)
{
    auto query = new QSqlQuery(db);
    QString insert{"INSERT INTO Login Values('"+username+"','"+password+"')"};
    if(!query->exec(insert))
         QMessageBox::critical(this,"Error","could not insert the task");

}
