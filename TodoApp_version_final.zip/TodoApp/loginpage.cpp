#include "loginpage.h"
#include "ui_loginpage.h"
#include "createcount.h"

LoginPage::LoginPage(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LoginPage)
{
    ui->setupUi(this);
    //create database
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("C:\\Users\\Hello\\Desktop\\db\\logindb.db");
    if(!db.open())
        QMessageBox::critical(this,"Error","could not open the database");

}

LoginPage::~LoginPage()
{
    delete ui;
}

void LoginPage::on_pushButton_clicked()
{
    QString Username = ui->lineEdit->text();
        QString Password = ui->lineEdit_2->text();

        if(!db.isOpen()){

            qDebug()<<"Failed to open the database!!";
            return;
        }

    QSqlQuery query;
    if(query.exec("select * from Login where username='"+Username+"' and password='"+Password+"'")){
        int count=0;
        while (query.next()) {
            count++;
        }
        if(count==1){
//            ui->label_3->setText("username and password is correct");
            QMessageBox::information(this,"Access","welcome "+Username);

            acceptLogin = true;
        }

        if(count<1){
//            ui->label_3->setText("username and password is not correct");
            QMessageBox::critical(this,"Error","username or password in not correct !! ");
            acceptLogin = false;
        }
    }
}


void LoginPage::on_pushButton_2_clicked()
{
    //Creating the dialog
     CreateCount D;

   //Executing the dialog and storing the user response
    auto reply = D.exec();

   //Checking if the dialog is accepted
    if(reply == CreateCount::Accepted)
     {
    auto query = new QSqlQuery(db);
    QString insert{"INSERT INTO Login Values('%1','%2')"};
    if(!query->exec(insert.arg(D.getusername()).arg(D.getpassword())))
         QMessageBox::critical(this,"Error","could not insert the user");
    else
        D.close();
    }
}

