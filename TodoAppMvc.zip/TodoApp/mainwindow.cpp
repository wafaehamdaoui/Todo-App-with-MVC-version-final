#include "mainwindow.h"
#include "login.h"
#include "tasks.h"
#include "find.h"
#include "remove.h"
#include <QLabel>
#include <QToolBar>
#include <QMenuBar>
#include <QBoxLayout>
#include <QSettings>
#include <QCloseEvent>
#include <QMessageBox>
#include <QApplication>
#include <QFile>
#include <QFileDialog>
#include <QTextStream>
#include <QWindow>
#include <QDate>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
//    Login loginDialog;
//    loginDialog.exec();
//    if(loginDialog.acceptLogin){



        QWidget* pWidget = new QWidget(this);
        //pWidget->setStyleSheet("background-color: #fffff0");
        setCentralWidget(pWidget);
        pWidget->setStyleSheet("background-image: url(:/back.jpg)");

        QVBoxLayout* pMainLayout = new QVBoxLayout();
        pWidget->setLayout(pMainLayout);

        QLabel* pwTitle = new QLabel("To Do List", this);
        pMainLayout->addWidget(pwTitle);
        pwTitle->setAlignment(Qt::AlignCenter);
        pwTitle->setStyleSheet("font-size: 30pt; margin: 10%;");

        auto pHLayoutLabels = new QHBoxLayout();
        pMainLayout->addLayout(pHLayoutLabels);

        QLabel* plblToday = new QLabel("ToDay", this);
        plblToday->setStyleSheet("font-size: 15pt;");
        pHLayoutLabels->addWidget(plblToday);

        QLabel* plblPending = new QLabel("Pending", this);
        plblPending->setStyleSheet("font-size: 15pt;");
        pHLayoutLabels->addWidget(plblPending);


        QHBoxLayout* pHLayout = new QHBoxLayout();
        QVBoxLayout* pVLayout = new QVBoxLayout();
        pMainLayout->addLayout(pHLayout);
        pMainLayout->addLayout(pVLayout);

        QLabel* plblCompleted = new QLabel("Completed", this);
        plblCompleted->setStyleSheet("font-size: 15pt;");
        pVLayout->addWidget(plblCompleted);


        todayList = new QTableView(this);
        todayList->setDragEnabled(true);
        todayList->setAcceptDrops(true);
        todayList->setDropIndicatorShown(true);
        todayList->setDefaultDropAction(Qt::MoveAction);
        pHLayout->addWidget(todayList);

        pendingList = new QTableView(this);
        pendingList->setDragEnabled(true);
        pendingList->setAcceptDrops(true);
        pendingList->setDropIndicatorShown(true);
        pendingList->setDefaultDropAction(Qt::MoveAction);
       pHLayout->addWidget(pendingList);

        completedList = new QTableView(this);
        completedList->setDragEnabled(true);
        completedList->setAcceptDrops(true);
        completedList->setDropIndicatorShown(true);
        completedList->setDefaultDropAction(Qt::MoveAction);
        pVLayout->addWidget(completedList);


        pendingList->setStyleSheet
        ("QTableView { font-size: 9pt; font-weight: bold; }"
         "QTableView { background-color: #FFFFFF;}");

        completedList->setStyleSheet
        ("QTableView { font-size: 9pt; font-weight: bold; }"
          "QTableView { background-color: #FFFFFF;}");

        todayList->setStyleSheet
        ("QTableView { font-size: 9pt; font-weight: bold; }"
          "QTableView { background-color: #FFFFFF;}");


        QToolBar *pToolBar = new QToolBar(this);
        addToolBar(pToolBar);


        AddAction = new QAction("Add Task",this);
        AddAction->setIcon(QIcon(":/add.jfif"));
        connect(AddAction, &QAction::triggered, this, &MainWindow::Add);

        RemoveAction = new QAction("Delete",this);
        RemoveAction->setIcon(QIcon(":/delete.jfif"));
        connect(RemoveAction, &QAction::triggered, this, &MainWindow::RemoveTask);

        pendingList->setContextMenuPolicy(Qt::CustomContextMenu);
        connect(pendingList, SIGNAL(customContextMenuRequested(QPoint)), this, SLOT(ProvideContextMenuP(QPoint)));


        todayList->setContextMenuPolicy(Qt::CustomContextMenu);
        connect(todayList, SIGNAL(customContextMenuRequested(QPoint)), this, SLOT(ProvideContextMenuT(QPoint)));


        completedList->setContextMenuPolicy(Qt::CustomContextMenu);
        connect(completedList, SIGNAL(customContextMenuRequested(QPoint)), this, SLOT(ProvideContextMenuC(QPoint)));


        saveActionP = new QAction("Pending List",this);
        saveActionP->setIcon(QIcon(":/pending.jfif"));
        saveActionT = new QAction("Today List",this);
        saveActionT->setIcon(QIcon(":/today.png"));
        saveActionF = new QAction("Finished List",this);
        saveActionF->setIcon(QIcon(":/completed.jfif"));

//        auto saveMenu = OptionsMenu->addMenu("Save");
//        saveMenu->addAction(saveActionP);
//        saveMenu->addAction(saveActionT);
//        saveMenu->addAction(saveActionF);

        connect(saveActionP, &QAction::triggered, this, &MainWindow::savePending);
        connect(saveActionT, &QAction::triggered, this, &MainWindow::saveToday);
        connect(saveActionF, &QAction::triggered, this, &MainWindow::saveFinished);


        closeAction = new QAction("Close",this);
        closeAction->setIcon(QIcon(":/download.jfif"));
        connect(closeAction, &QAction::triggered, this, &MainWindow::close);

        clearAction = new QAction("Clear",this);
        clearAction->setIcon(QIcon(":/clear.jpg"));
        connect(clearAction, &QAction::triggered, this, &MainWindow::clear);

        findAction = new QAction("Find",this);
        findAction->setIcon(QIcon(":/find.png"));
        connect(findAction, &QAction::triggered, this, &MainWindow::find);

        minimiseAction = new QAction("Minimise",this);
        minimiseAction->setIcon(QIcon(":/mi.jfif"));
        connect(minimiseAction, &QAction::triggered, this, &MainWindow::showMinimized);
        maximiseAction = new QAction("Maximise",this);
        maximiseAction->setIcon(QIcon(":/max.png"));
        connect(maximiseAction, &QAction::triggered, this, &MainWindow::showMaximized);


        showabout = new QAction("About",this);
        showabout->setIcon(QIcon(":/about.jfif"));
        connect(showabout, &QAction::triggered, this, &MainWindow::About);

        Fullscreen = new QAction("Fullscreen",this);
        Fullscreen->setIcon(QIcon(":/full.jfif"));
        connect(Fullscreen, &QAction::triggered, this, &MainWindow::showFullScreen);

        // File Menu
        FileMenu = menuBar()->addMenu("&File");
        FileMenu->addAction(AddAction);
        FileMenu->addAction(RemoveAction);
        FileMenu->addAction(closeAction);

        // options menu
        OptionsMenu=menuBar()->addMenu("&Options");

        OptionsMenu->addAction(findAction);
        OptionsMenu->addAction(clearAction);

        auto save = OptionsMenu->addMenu("&Save");
        save->addAction(saveActionP);
        save->addAction(saveActionT);
        save->addAction(saveActionF);

        // window menu
        WindowMenu = menuBar()->addMenu("&Window");
        WindowMenu->addAction(minimiseAction);
        WindowMenu->addAction(maximiseAction);
        WindowMenu->addAction(Fullscreen);

        // Help menu
        helpMenu = menuBar()->addMenu("&Help");
        helpMenu->addAction(showabout);



        pToolBar->addAction(AddAction);
        pToolBar->addAction(RemoveAction);
//        pToolBar->addMen(saveAction);
        pToolBar->addAction(closeAction);
        pToolBar->addAction(clearAction);
        pToolBar->addAction(findAction);

        connect(pendingList, &QListWidget::doubleClicked, this, &MainWindow::ModifyP);
        connect(todayList, &QListWidget::doubleClicked, this, &MainWindow::ModifyT);
        connect(completedList, &QListWidget::doubleClicked, this, &MainWindow::ModifyC);



        connectDataBase();
        loadList();



}

MainWindow::~MainWindow()
{
    delete pendingList ;
    delete completedList;
    delete todayList ;

    delete AddAction ;
    delete RemoveAction ;
    delete closeAction;
    delete clearAction;
    delete findAction;
    delete minimiseAction;
    delete maximiseAction;
    delete showabout;
    delete FileMenu;
    delete OptionsMenu;
    delete helpMenu;
    delete WindowMenu;
}
void MainWindow::Add()
{
    //Creating the dialog
        Tasks D;

//        Executing the dialog and storing the user response
        auto reply = D.exec();

//        Checking if the dialog is accepted
        if(reply == Tasks::Accepted)
        {
            Addquery(D.getDescription() , D.getTag()  , D.getDate(), D.isCompleted());
            loadList();

        }
  }


void MainWindow::RemoveTask()
{
    auto reply=QMessageBox::question(this,"Remove Task","do you really want to remove this task ??");
     if(reply == QMessageBox::Yes){
         //Creating the dialog
           Remove D;

          //Executing the dialog and storing the user response
           auto reply = D.exec();

           //Checking if the dialog is accepted

          if(reply == Remove::Accepted){
              auto model = new QSqlQueryModel;
              auto query = new QSqlQuery(db);
              QString view{"DELETE FROM Tasks WHERE Description='"+D.getDescription()+"' "};
              query->exec(view);
              model->setQuery(*query);
              pendingList->setModel(model);
              completedList->setModel(model);
              todayList->setModel(model);
              loadList();
          }

     }
}


//void MainWindow::RemoveFinished(){
//    auto reply=QMessageBox::question(this,"Remove Task","do you really want to remove this task ??");
//     if(reply == QMessageBox::Yes){
//         //Creating the dialog
//           Remove D;

//          //Executing the dialog and storing the user response
//           auto reply = D.exec();

//           //Checking if the dialog is accepted

//          if(reply == Remove::Accepted){
//              auto model = new QSqlQueryModel;
//              auto query = new QSqlQuery(db);
//              QString view{"DELETE FROM Tasks WHERE Description='"+D.getDescription()+"' "};
//              query->exec(view);
//              model->setQuery(*query);
//              completedList->setModel(model);
//              loadList();}
//      }
//}

//void MainWindow::RemoveToday(){
//    auto reply=QMessageBox::question(this,"Remove Task","do you really want to remove this task ??");
//     if(reply == QMessageBox::Yes){
//         //Creating the dialog
//           Remove D;

//          //Executing the dialog and storing the user response
//           auto reply = D.exec();

//           //Checking if the dialog is accepted

//          if(reply == Remove::Accepted){
//              auto model = new QSqlQueryModel;
//              auto query = new QSqlQuery(db);
//              QString view{"DELETE FROM Tasks WHERE Description='"+D.getDescription()+"' "};
//              query->exec(view);
//              model->setQuery(*query);
//              todayList->setModel(model);
//              loadList();
//          }
//     }
//}

void MainWindow::close()
{
        auto reply = QMessageBox::question(this, "Exit",
                                           "Do you really want to quit?");
        if(reply == QMessageBox::Yes)
            qApp->exit();
}

void MainWindow::clear()
{
    //model
    auto model = new QSqlQueryModel;
    auto query = new QSqlQuery(db);
    QString view{"DELETE FROM Tasks "};
    query->exec(view);
    model->setQuery(*query);
    pendingList->setModel(model);
    loadList();

}
//}
void MainWindow::find(){
        //Creating the dialog
        Find D;

       //Executing the dialog and storing the user response
        auto reply = D.exec();

       //Checking if the dialog is accepted
        if(reply == Find::Accepted)
         {

           //Getting the search text
           auto search = D.getsearch();
           for(int row=pendingList->model()->rowCount();row>=0;row--){
               if(pendingList->model()->data(pendingList->model()->index(row,0)).toString()==search)
                   pendingList->setCurrentIndex(pendingList->model()->index(row,0));
           }
           for(int row=todayList->model()->rowCount();row>=0;row--){
               if(todayList->model()->data(todayList->model()->index(row,0)).toString()==search)
                   todayList->setCurrentIndex(todayList->model()->index(row,0));
           }
           for(int row=completedList->model()->rowCount();row>=0;row--){
               if(completedList->model()->data(completedList->model()->index(row,0)).toString()==search)
                   completedList->setCurrentIndex(completedList->model()->index(row,0));
           }


   }

}

void MainWindow::loadList(){
    //model
    auto model = new QSqlQueryModel;
    auto query = new QSqlQuery(db);
    QString view{"SELECT * FROM Tasks WHERE finished=TRUE"};
    query->exec(view);
    model->setQuery(*query);
    completedList->setModel(model);

    auto TodayDate=QDate::currentDate().toString();

    auto model1 = new QSqlQueryModel;
    auto query1 = new QSqlQuery(db);
    QString view1{"SELECT * FROM Tasks WHERE finished=FALSE AND Date='"+TodayDate+"'"};
    query1->exec(view1);
    model1->setQuery(*query1);
    todayList->setModel(model1);


    //pending list:
    auto model2 = new QSqlQueryModel;
    auto query2 = new QSqlQuery(db);
    QString view2{"SELECT * FROM Tasks WHERE finished=FALSE AND Date!='"+TodayDate+"'"};
    query2->exec(view2);
    model2->setQuery(*query2);
//    int rowCount = model2->rowCount();
    pendingList->setModel(model2);


}

void MainWindow::saveList(QTableView *listWidget , QString filename){
    QString textData;
    int rows = listWidget->model()->rowCount();
    int columns = listWidget->model()->columnCount();

    // .csv
    QFile csvFile(filename);
    if(csvFile.open(QIODevice::WriteOnly)) {

        QTextStream stream(&csvFile);
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {

                    textData += listWidget->model()->data(listWidget->model()->index(i,j)).toString();
                    textData += ", "  ;    // for .csv file format
            }
            textData += "\n";
        }
        stream << textData;

        csvFile.close();}
    }

void MainWindow::savePending(){

        //Creating a file dialog to choose a file graphically
        auto dialog = new QFileDialog(this);

        //Check if the current file has a name or not
        if(currentFile == "")        {
           currentFile = dialog->getSaveFileName(this,"choose your file");

           //Update the window title with the file name
           setWindowTitle(currentFile);
        }

       //If we have a name simply save the content
       if( currentFile != ""){

               saveList(pendingList,currentFile);
}}

void MainWindow::saveToday(){

        //Creating a file dialog to choose a file graphically
        auto dialog = new QFileDialog(this);

        //Check if the current file has a name or not
        if(currentFile == "")        {
           currentFile = dialog->getSaveFileName(this,"choose your file");

           //Update the window title with the file name
           setWindowTitle(currentFile);
        }

       //If we have a name simply save the content
       if( currentFile != ""){

             saveList(todayList,currentFile);


                      }

    }

void MainWindow::saveFinished(){

        //Creating a file dialog to choose a file graphically
        auto dialog = new QFileDialog(this);

        //Check if the current file has a name or not
        if(currentFile == "")        {
           currentFile = dialog->getSaveFileName(this,"choose your file");

           //Update the window title with the file name
           setWindowTitle(currentFile);
        }

       //If we have a name simply save the content
       if( currentFile != ""){

               saveList(completedList,currentFile);

                      }

    }


void MainWindow::About()
      {
          QMessageBox::about(this, "About this app",
                              "This is a simple todo application that manages your tasks , hope you like it ");
       }
void MainWindow::modifyTask(QTableView* listWidget){
      Tasks D;
//       auto test=listWidget->currentItem()->text();
      QString textData;
//      auto rows = listWidget->currentIndex();
      int columns = listWidget->model()->columnCount();
//      for (int i = 0; i < rows; i++) {
          for (int j = 0; j < columns; j++) {

          textData += listWidget->model()->data(listWidget->model()->index((listWidget->currentIndex().row()),j)).toString();
          textData += ", "  ;}
          auto text =textData.split(",");

       D.setDescription(text[0]);
       D.setTag(text[1]);
       QString date = text[2];
       QDate Date = QDate::fromString(date);
      D.SetDate(Date);

       if(listWidget == completedList)
           D.setFinished();


    auto reply = D.exec();
    if(reply == Tasks::Accepted){
//        listWidget->model()->removeRow(listWidget->currentIndex().row());
//        pendingList->setEditTriggers(QAbstractItemView::EditTriggers());
        auto model = new QSqlQueryModel;
        auto query = new QSqlQuery(db);
        QString view{"DELETE FROM Tasks WHERE Description='"+D.getDescription()+"' "};
        query->exec(view);
        model->setQuery(*query);
        pendingList->setModel(model);
        completedList->setModel(model);
        todayList->setModel(model);
        Addquery(D.getDescription() , D.getTag()  , D.getDate(), D.isCompleted());
        loadList();
    }
}

//        delete listWidget->currentItem();

    //    auto temp = "Task: "+D.getDescription()+",Tag: "+D.getTag()+",Due: "+D.getDate();
///// //               /* completedListItem.append({D.getDescription(),D.getTag(),D.getDate()});
//// //                is*/Finished=true;

////        }else if(D.isToday()){
////            todayList->insertItem(todayList->count(),temp);
////            todayList->item(todayList->count()-1)->setIcon(QIcon( ":/today.png"));

//// //                todayListItem.append({D.getDescription(),D.getTag(),D.getDate()});
////        }else{
////            pendingList->insertItem(pendingList->count(),temp);
////            pendingList->item(pendingList->count()-1)->setIcon(QIcon( ":/pending.jfif"));
//// //                pendingListItem.append({D.getDescription(),D.getTag(),D.getDate()});
////        }

////    }
////    saveList(pendingList,currentFile);
////    saveList(todayList,currentFile);
////    saveList(completedList,currentFile);

////}

void MainWindow::ModifyP(){
    modifyTask(pendingList);
}

void MainWindow::ModifyC(){
    modifyTask(completedList);
}

void MainWindow::ModifyT(){
    modifyTask(todayList);
}

void MainWindow::ProvideContextMenuP(const QPoint &pos)
{
    // Handle global position
        QPoint globalPos = pendingList->mapToGlobal(pos);

        // Create menu and insert some actions
        QMenu myMenu;
        myMenu.addAction("Insert", this, SLOT(Add()))->setIcon(QIcon(":/add.jfif"));
        myMenu.addAction("Modify", this, SLOT(ModifyP()))->setIcon(QIcon(":/modify.png"));
        myMenu.addAction("Erase",  this, SLOT(RemoveTask()))->setIcon(QIcon(":/delete.jfif"));

        // Show context menu at handling position
        myMenu.exec(globalPos);

}

void MainWindow::ProvideContextMenuT(const QPoint &pos)
{
    // Handle global position
        QPoint globalPos = todayList->mapToGlobal(pos);

        // Create menu and insert some actions
        QMenu myMenu;
        myMenu.addAction("Insert", this, SLOT(Add()))->setIcon(QIcon(":/add.jfif"));
        myMenu.addAction("Modify", this, SLOT(ModifyT()))->setIcon(QIcon(":/modify.png"));
        myMenu.addAction("Erase",  this, SLOT(RemoveTask()))->setIcon(QIcon(":/delete.jfif"));

        // Show context menu at handling position
        myMenu.exec(globalPos);

}

void MainWindow::ProvideContextMenuC(const QPoint &pos){

    // Handle global position
        QPoint globalPos = completedList->mapToGlobal(pos);

        // Create menu and insert some actions
        QMenu myMenu;
        myMenu.addAction("Insert", this, SLOT(Add()))->setIcon(QIcon(":/add.jfif"));
        myMenu.addAction("Modify", this, SLOT(ModifyC()))->setIcon(QIcon(":/modify.png"));
        myMenu.addAction("Erase",  this, SLOT(RemoveTask()))->setIcon(QIcon(":/delete.jfif"));
        // Show context menu at handling position
        myMenu.exec(globalPos);
}
void MainWindow::connectDataBase(){

    //create database
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("C:\\Users\\Hello\\Desktop\\db\\DataBase.db");
    if(!db.open())
        QMessageBox::critical(this,"Error","could not open the database");

    //create table
    auto query = new QSqlQuery(db);
    QString create{"CREATE TABLE IF NOT EXISTS Tasks(ID INTEGER NOT NULL PRIMARY KEY , Description varchar(800), Tag varchar(80), Date varchar(80), Finished BOOLEAN)"};
    if(!query->exec(create))
        QMessageBox::critical(this,"Error","could not open the table");



}
void MainWindow::Addquery(QString description ,QString Tag , QString date, bool finished )
{
    auto query = new QSqlQuery(db);
    QString insert{"INSERT INTO Tasks Values('%1','%2','%3','%4')"};
    if(!query->exec(insert.arg(description).arg(Tag).arg(date).arg(finished)))
         QMessageBox::critical(this,"Error","could not insert the task");

}

