#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTableView>
#include <QListWidget>
#include <QSqlDatabase>

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

      void loadList();
      void saveList(QTableView *listWidget , QString filename);
    void modifyTask(QTableView* listWidget);
    bool removeRow(int position, int rows, const QModelIndex &parent);


protected slots:
    void Add();
    void RemoveTask();
//    void RemoveFinished();
//    void RemoveToday();
    void close();
    void clear();
    void find();
    void savePending();
    void saveFinished();
    void saveToday();
    void About();
    void ModifyP();
    void ModifyC();
    void ModifyT();
    void ProvideContextMenuP(const QPoint&);
    void ProvideContextMenuT(const QPoint&);
    void ProvideContextMenuC(const QPoint&);

protected:
    void connectDataBase();
    void Addquery(QString description ,QString Tag  , QString date, bool finished);

private:
    QTableView *pendingList = nullptr;
    QTableView *completedList = nullptr;
    QTableView *todayList = nullptr;
    QListWidget *trashList = nullptr;

    QAction* AddAction ;
    QAction* RemoveAction ;
    QAction* closeAction;
    QAction* clearAction;
    QAction* findAction;
    QAction* saveActionP;
    QAction* saveActionF;
    QAction* saveActionT;
    QAction* minimiseAction;
    QAction* maximiseAction;
    QAction* showabout;
    QAction* Fullscreen;

    //Menus
    QMenu *FileMenu;
    QMenu *OptionsMenu;
//    QMenu* saveMenu;
    QMenu *helpMenu;
    QMenu *WindowMenu;

//    //file
    QString currentFile = "";

    //database
    QSqlDatabase db;

};
#endif // MAINWINDOW_H
