#include "remove.h"
#include "ui_remove.h"

Remove::Remove(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Remove)
{
    ui->setupUi(this);
}

Remove::~Remove()
{
    delete ui;
}
QString Remove::getId() const{
    return ui->ID->text();

}
QString Remove::getDescription() const{
    return ui->description->text();

}
