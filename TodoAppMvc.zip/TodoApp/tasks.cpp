#include "tasks.h"
#include "ui_tasks.h"

Tasks::Tasks(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Tasks)
{
    ui->setupUi(this);
}

Tasks::~Tasks()
{
    delete ui;
}
// Return whether or not 'checkbox' UI element is checked
bool Tasks::isCompleted() const
{
    return ui->checkBox->isChecked();
}

void Tasks::setFinished()
{
     ui->checkBox->setChecked(true);
}

QString Tasks::getDescription() const
{
    return ui->lineEdit->text();
}

QString Tasks::getTag() const
{
    return ui->comboBox->currentText();
}

QString Tasks::getDate() const
{
    return ui->dateEdit->date().toString();
}
bool Tasks::isToday(){

    if(ui->dateEdit->date() == QDate::currentDate())
        return true;
    return false;
}

void Tasks::setDescription(QString description) const{
    ui->lineEdit->setText(description);
}

void Tasks::setTag(QString tag) const
{
    ui->comboBox->setCurrentText(tag);
}


void Tasks::SetDate(QDate date) const
{
     ui->dateEdit->setDate(date);
}
