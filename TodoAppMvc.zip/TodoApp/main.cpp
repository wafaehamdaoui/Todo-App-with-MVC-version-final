#include "mainwindow.h"
#include "loginpage.h"
#include <QApplication>
#include <QDialog>
#include <QMessageBox>
#include "ui_login.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    LoginPage loginDialog;
    loginDialog.exec();
    if(loginDialog.acceptLogin){
    MainWindow w;
    w.show();
    return a.exec();
}
    return 0;

}
