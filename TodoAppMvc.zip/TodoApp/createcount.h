#ifndef CREATECOUNT_H
#define CREATECOUNT_H
#include <QSqlDatabase>
#include <QDialog>

namespace Ui {
class CreateCount;
}

class CreateCount : public QDialog
{
    Q_OBJECT

public:
    explicit CreateCount(QWidget *parent = nullptr);
    ~CreateCount();
    QString getusername();
    QString getpassword();

protected:
    void connectDataBase();
    void Addquery(QString username ,QString password);

private slots:
    void on_pushButton_clicked();

private:
    Ui::CreateCount *ui;
     QSqlDatabase db;

};

#endif // CREATECOUNT_H
