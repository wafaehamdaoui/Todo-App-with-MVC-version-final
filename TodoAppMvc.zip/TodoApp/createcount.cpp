#include "createcount.h"
#include "ui_createcount.h"
#include "loginpage.h"
#include <QMessageBox>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QDebug>


CreateCount::CreateCount(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CreateCount)
{
    ui->setupUi(this);
//    connectDataBase();
//    Addquery(getusername(),getpassword());


}

CreateCount::~CreateCount()
{
    delete ui;
}
QString CreateCount::getusername(){
    ui->lineEdit->text();
}
QString CreateCount::getpassword(){
    ui->lineEdit_2->text();
}

void CreateCount::connectDataBase(){

    //create database
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("C:\\Users\\Hello\\Desktop\\db\\logindb.db");
    if(!db.open())
        QMessageBox::critical(this,"Error","could not open the database");

    //create table
    auto query = new QSqlQuery(db);
    QString create{"CREATE TABLE IF NOT EXISTS Login (username varchar(30), password varchar(30))"};
    if(!query->exec(create))
        QMessageBox::critical(this,"Error","could not open the table");



}
void CreateCount::Addquery(QString username ,QString password)
{
    auto query = new QSqlQuery(db);
    QString insert{"INSERT INTO Login Values('"+username+"','"+password+"')"};
    if(!query->exec(insert))
         QMessageBox::critical(this,"Error","could not insert the task");

}

void CreateCount::on_pushButton_clicked()
{
    connectDataBase();
    Addquery(getusername(),getpassword());
    LoginPage loginDialog;
    loginDialog.exec();
}

